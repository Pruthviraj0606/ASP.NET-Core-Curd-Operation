using CRMEMP.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace CRMEMP.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        public EmpContext empCon;


        public HomeController(ILogger<HomeController> logger, EmpContext empCon)
        {
            _logger = logger;
            this.empCon = empCon;
        }

        public IActionResult Index()
        {
            var t = empCon.employee.ToList();
            return View(t);
        }

        public IActionResult Privacy()
        {
            return View();
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(String Emp_name, String Emp_desc, String Emp_email)
        {
            if(ModelState.IsValid)
            {
            Emp emp = new Emp();
            emp.Emp_name = Emp_name;    
            emp.Emp_desc = Emp_desc; 
            emp.Emp_email = Emp_email;

            empCon.employee.Add(emp);
            empCon.SaveChanges();
            return RedirectToAction("Index");
            }
            return View();
        }
        [HttpGet]
        public IActionResult Deatils(int id)
        {
            var v = empCon.employee.Where(x => x.Emp_id == id).FirstOrDefault();
            return View(v);
        }
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var v = empCon.employee.Where(x => x.Emp_id == id).FirstOrDefault();
            empCon.employee.Remove(v);
            empCon.SaveChanges();
            return RedirectToAction("index");
        }
        [HttpGet]
        public IActionResult Edit(int id)
        {
            var v = empCon.employee.Where(x => x.Emp_id == id).FirstOrDefault();
            return View(v);
        }
        [HttpPost]
        public IActionResult Edit(int Emp_id, String Emp_name, String Emp_desc, String Emp_email)
        {
            Emp em=new Emp();
            em.Emp_id = Emp_id;
            em.Emp_name = Emp_name;
            em.Emp_desc = Emp_desc;
            em.Emp_email = Emp_email;
           
            empCon.employee.Update(em);
            empCon.SaveChanges();
                
            return RedirectToAction("Index");
        }


        

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
