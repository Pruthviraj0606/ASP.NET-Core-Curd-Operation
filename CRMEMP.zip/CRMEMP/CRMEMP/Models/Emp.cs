﻿using System.ComponentModel.DataAnnotations;

namespace CRMEMP.Models
{
    public class Emp
    {
        [Key]
        public int Emp_id { get; set; }

        [Required(ErrorMessage = "*")]
        public String Emp_name { get; set; }

        [Required(ErrorMessage = "*")]
        public String Emp_desc { get; set; }

        [Required(ErrorMessage = "*")]
        public String Emp_email {  get; set; }
            
    }
}
