﻿using Microsoft.EntityFrameworkCore;

namespace CRMEMP.Models
{
    public class EmpContext : DbContext
    {
        public EmpContext(DbContextOptions<EmpContext>options) 
            :base(options) { }
        
        public DbSet<Emp> employee { get; set; }
    }
}
